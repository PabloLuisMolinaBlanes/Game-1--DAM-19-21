# litiengine-gurk-nukem
An example 2D platformer with shooter elements made in the LITIengine
