# This source folder container all maps for the game

Although they will be loaded from the `.litidata` file later, it is a good practice to keep the source files for the maps in the same directory as the game.