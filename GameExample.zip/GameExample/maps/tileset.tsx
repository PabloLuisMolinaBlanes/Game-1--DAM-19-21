<?xml version="1.0" encoding="UTF-8"?>
<tileset firstgid="0" name="tileset" tilewidth="8" tileheight="8" tilecount="256" columns="16">
 <image source="tileset.png" width="128" height="128"/>
 <tile id="7">
  <animation>
   <frame tileid="7" duration="300"/>
   <frame tileid="8" duration="100"/>
  </animation>
 </tile>
</tileset>
