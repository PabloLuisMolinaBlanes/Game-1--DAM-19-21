<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="buch-outdoor" tilewidth="32" tileheight="32" tilecount="72" columns="12">
 <image source="../../../../../Program Files/Tiled/examples/buch-outdoor.png" width="384" height="192"/>
</tileset>
