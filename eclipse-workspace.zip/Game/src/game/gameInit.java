package game;
import de.gurkenlabs.litiengine.Game;
import de.gurkenlabs.litiengine.IUpdateable;
import de.gurkenlabs.litiengine.annotation.CollisionInfo;
import de.gurkenlabs.litiengine.annotation.EntityInfo;
import de.gurkenlabs.litiengine.annotation.MovementInfo;
import de.gurkenlabs.litiengine.entities.Creature;
import de.gurkenlabs.litiengine.gui.screens.GameScreen;
import de.gurkenlabs.litiengine.input.PlatformingMovementController;
import de.gurkenlabs.litiengine.resources.Resources;
public class gameInit {
	public static void main(String[] args) {
	    // set meta information about the game
	    Game.info().setName("GURK NUKEM");
	    Game.info().setSubTitle("");
	    Game.info().setVersion("v0.0.1");
	    Game.info().setWebsite("https://github.com/gurkenlabs/litiengine-gurk-nukem");
	    Game.info().setDescription("An example 2D platformer with shooter elements made in the LITIengine");
	    // init the game infrastructure
	    Game.init(args);
	    // set the icon for the game (this has to be done after initialization because the ScreenManager will not be present otherwise)
	    Game.window().setIconImage(Resources.images().get("icon.png"));
	    Game.graphics().setBaseRenderScale(4.001f); 
	    // load data from the utiLITI game file
	    Resources.load("game.litidata");
	    // load the first level (resources for the map were implicitly loaded from the game file)
	    Game.world().loadEnvironment("level1.tmx");
	    Game.start();
	    gameInit game = new gameInit();
	    Game.screens().add(game.new IngameScreen());
	    GurkNukemLogic.init();
	    PlayerInput.init();
	  }
	public class IngameScreen extends GameScreen {
	    public static final String NAME = "INGAME-SCREEN";
	    public IngameScreen() {
	      super(NAME);
	    }
	  }
    }
